﻿namespace JwtBearerSample
{
    public class Todo
    {
        public string Description { get; set; }
        public string Owner { get; set; }
    }
}
