﻿namespace GenericHostSample
{
    internal class MyContainer
    {
    }
}