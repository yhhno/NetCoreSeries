Hosting
=======
AppVeyor: [![AppVeyor](https://ci.appveyor.com/api/projects/status/99mq30o3hcs9p39n/branch/dev?svg=true)](https://ci.appveyor.com/project/aspnetci/Hosting/branch/dev)

Travis:   [![Travis](https://travis-ci.org/aspnet/Hosting.svg?branch=dev)](https://travis-ci.org/aspnet/Hosting)

The Hosting repo contains code required to host an ASP.NET Core application, it is the entry point used when self-hosting an application.

This project is part of ASP.NET Core. You can find samples, documentation and getting started instructions for ASP.NET Core at the [Home](https://github.com/aspnet/home) repo.
