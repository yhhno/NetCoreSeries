Compile the solution in Release mode (so binaries are available in release)

To run a specific benchmark add it as parameter.
```
dotnet run -c Release <benchmark_name>
```

If you run without any parameters, you'll be offered the list of all benchmarks and get to choose.
```
dotnet run -c Release
```