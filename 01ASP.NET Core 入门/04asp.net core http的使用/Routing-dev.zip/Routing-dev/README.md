ASP.NET Routing
===

AppVeyor: [![AppVeyor](https://ci.appveyor.com/api/projects/status/fe4o5h1s9ve86nyv/branch/dev?svg=true)](https://ci.appveyor.com/project/aspnetci/Routing/branch/dev)

Travis:   [![Travis](https://travis-ci.org/aspnet/Routing.svg?branch=dev)](https://travis-ci.org/aspnet/Routing)

Contains routing middleware for routing requests to application logic.

This project is part of ASP.NET Core. You can find samples, documentation and getting started instructions for ASP.NET Core at the [Home](https://github.com/aspnet/home) repo.
